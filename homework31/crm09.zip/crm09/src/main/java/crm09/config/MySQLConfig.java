package crm09.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class MySQLConfig {
	public static Connection getConnection() {
		Connection connection = null;
		try {
			String url = "jdbc:mysql://localhost:3307/crmapp"; //Depends on the db we use. Each has a different url
			String username = "root";
			String password = "admin123";
			// Declare driver for the database we need (here we use mySql
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(url, username, password);
			
		} catch (Exception e) {
			System.out.println("Error when trying to connect to the database" + e.getMessage());
		}
		return connection;
	}
}
