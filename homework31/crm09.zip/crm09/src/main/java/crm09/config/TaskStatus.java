package crm09.config;

public enum TaskStatus {
	COMPLETED,
	WIP,
	PENDING
}
