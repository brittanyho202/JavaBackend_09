package crm09.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import crm09.config.MySQLConfig;
import crm09.entity.Role;
import crm09.entity.User;
import utils.Md5Helper;

public class UserRepository {
	public List<User> findAllUsers() {
		List<User> listUsers = new ArrayList<User>();
		String query = "SELECT * FROM users";
		Connection connection = MySQLConfig.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				User user = new User();
				user.setId(resultSet.getInt("id")); // gets the value from the 'id' column 
				user.setEmail(resultSet.getString("email")); // gets the value from the 'name' column
				
				listUsers.add(user);
			}
			
		} catch (Exception e) {
			System.out.println("Error findAllUsers: " + e.getMessage());
		}
		return listUsers;
	}
	
	public int saveUser(String email, String password, int roleID, String fullname, String phone) { // return the number of line updated?
		int count = 0;
		String query = "INSERT INTO users(email, password, id_role, phone, fullname)\n"
				+ "VALUES(?, ?, ?, ?, ?)";
		
		Connection connection = MySQLConfig.getConnection();
		
		try {
			PreparedStatement statement = connection.prepareStatement(query);
//			ResultSet resultSet = statement.executeQuery(); // for SELECT
			statement.setString(1, email);
			statement.setString(2, Md5Helper.getMd5(password));
			statement.setInt(3, roleID);
			statement.setString(4, phone);
			statement.setString(5, fullname);
			
			count = statement.executeUpdate(); // Returns number of rows inserted (should be 1 for INSERT)
			
		} catch (Exception e) {
			System.out.println("Error saveUser: " + e.getMessage());
		}
		
		return count;
	}
}
