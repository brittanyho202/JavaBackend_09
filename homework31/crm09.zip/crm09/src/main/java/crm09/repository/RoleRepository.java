package crm09.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import crm09.config.MySQLConfig;
import crm09.entity.Role;

public class RoleRepository {
	// SELECT * FROM .... --> findAll.../getAll
	public List<Role> findAllRoles() {
		List<Role> listRoles = new ArrayList<Role>();
		String query = "SELECT * FROM roles";
		Connection connection = MySQLConfig.getConnection();
		try {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				Role role = new Role();
				role.setId(resultSet.getInt("id")); // gets the value from the 'id' column 
				role.setName(resultSet.getString("name")); // gets the value from the 'name' column
				
				listRoles.add(role);
			}
			
		} catch (Exception e) {
			System.out.println("Error findAllRoles: " + e.getMessage());
		}
		return listRoles;
	}
	
}
