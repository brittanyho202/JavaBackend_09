package crm09.service;

import java.util.List;

import crm09.entity.Role;
import crm09.repository.RoleRepository;
import crm09.repository.UserRepository;

public class UserService {
	private RoleRepository roleRepository = new RoleRepository();
	private UserRepository userRepository = new UserRepository();
	public List<Role> getAllRoles() {
		return roleRepository.findAllRoles();
	}
	
	public boolean insertUser(String email, String password, int roleID, String fullname, String phone) {
		
		return userRepository.saveUser(email, password, roleID, fullname, phone) > 0;
	}
}
