package crm09.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crm09.config.MySQLConfig;
import crm09.entity.Role;
import crm09.entity.User;
import utils.Md5Helper;

// Where we handle the connection to our login page
@WebServlet(name = "loginController", urlPatterns = {"/login"})
public class LoginController extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		req.getRequestDispatcher("login.html").forward(req, resp);
		Cookie[] cookies;
		String username = "";
		String password = "";
		
		if(req.getCookies() != null) {
			cookies = req.getCookies();
			for (Cookie cookie : cookies) {
				String name = cookie.getName();
				String value = cookie.getValue();
				
				if(name.equals("sUsername")) {
					username = value;
				}
				
				if(name.equals("sPassword")) {
					password = value;
				}
			}
		}
		
		
		req.setAttribute("email", username);
		req.setAttribute("password", password);
		
		req.getRequestDispatcher("login.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Step 1: Get the input from the user when they click button "Submit"
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		
		// Step 2: Prepare queries
//		String queries = "SELECT *\n"
//				+ "FROM users as u\n"
//				+ "WHERE u.email = 'nguyenvana@gmail.com' AND u.password = '123456'";
//		
		String query = "SELECT *\n"
				+ "FROM users as u\n"
				+ "JOIN roles r ON u.id_role = r.id \n"
				+ "WHERE u.email = ? AND u.password = ? ";
		
		// Step 3: Open a connection to the database
		Connection connection = MySQLConfig.getConnection();
		
		// Step 4: Pass the queries to the newly established connection to send it to the database
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			// As of right now, we have just sent the query to the database, we haven't execute the query yet
			
			// a. Pass the parameter to the ?
			preparedStatement.setString(1, email); // 1 = the position of the ? in the query
//			preparedStatement.setString(2, password);
			preparedStatement.setString(2, Md5Helper.getMd5(password));
			
			//Execute the query
			/**
			 * We use one of the following 2:
			 * executeQuery: The query is a SELECT query
			 * executeUpdate: The query is not a SELECT query (like update, delete)
			 */
			
			ResultSet resultSet = preparedStatement.executeQuery();
			List<User> usersList= new ArrayList<User>();
			// Map each entry in resultSet to the list's items
			while(resultSet.next()) {
				User user = new User();
				user.setId(resultSet.getInt("id"));
				user.setEmail(resultSet.getString("email"));
				Role role = new Role();
				role.setName(resultSet.getString("name"));
				user.setRole(role);
				usersList.add(user);
			}
			
			String roleName = usersList.get(0).getRole().getName();
			if(usersList.size() > 0) {
				// Create Cookie
				Cookie cookie = new Cookie("sUsername", email);
				cookie.setMaxAge(5*60); //second
				
				Cookie cookiePassword = new Cookie("sPassword", password);
				Cookie cookieRole = new Cookie("sRole", roleName);
				
				resp.addCookie(cookie);
				resp.addCookie(cookiePassword);
				resp.addCookie(cookieRole);
				
				System.out.println("Login Successful.");
			} else {
				System.out.println("Login Failed.");
			}
			
			// Logic to check how many failed times
			
		} catch (SQLException e) {
			System.out.println("Error when sending query to the database" + e.getMessage());
			e.printStackTrace();
		}
			
		
		req.getRequestDispatcher("login.jsp").forward(req, resp);
	}
}
