package crm09.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
												// urlPatterns: Filter will be activated when user calls the URL
@WebFilter(filterName = "authentication", urlPatterns = {"/user-add", "/role-add", "/role", "/user"})
public class AuthenticationFilter extends HttpFilter{
		/**
		 * Homework:
		 * - /user-add: need ADMIN role to access
		 * - /user : just need a login to access
		 * - Need to use filter
		 */
	
	@Override
	protected void doFilter(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		Cookie[] cookies = req.getCookies();
		boolean signedIn = false;
		String role = "";
		
		for (Cookie cookie : cookies) {
			
			if (cookie.getName().equals("sUsername")) {
				signedIn = true;
				System.out.println("Signed in successfully.");
			} else if (cookie.getName().equals("sRole")) {
				role = cookie.getValue();
			}
			
		}
		
		if(signedIn) {
			if (role.equals("ADMIN")) {
				chain.doFilter(req, res);
				System.out.println("Accessing Admin Level");
			} else {
				res.sendRedirect("login");
				System.out.println("Accessing User Level");
			}
			
		} else {
			res.sendRedirect("login");
			System.out.println("Most basic level - Non user");
		}
	}
}
